<template>
  <el-container>
    <el-header height="140">
      <Header />
    </el-header>
    <el-main>
      <router-view></router-view>
    </el-main>
    <el-footer height="20vw">
      <Footer/>
    </el-footer>
  </el-container>
</template>

<script>
// import HelloWorld from "./components/HelloWorld.vue";
import Header from "./components/header.vue";
import Footer from "./components/footer.vue";
export default {
  name: "app",
  components: {
    Header,
    Footer,
  },
  data() {
    return {};
  },
  created(){
    if(!localStorage.lang){
      localStorage.lang = 'cn'
    }else{
      this.$i18n.locale = localStorage.lang ;
    }
  },
  methods: {}
};
</script>

<style>
body {
  font-family: "SourceHanSansSC-Regular";
  width: 100%;
  margin: 0 auto;
  color: #333;
  overflow-x: hidden;
}
a,
a:hover {
  text-decoration: none;
}
footer.el-footer {
  padding: 0;
}
.popper__arrow {
  display: none !important;
}
.h1 {
  font-size: 80px;
}
.h2 {
  font-size: 60px;
}
.h3 {
  font-size: 36px;
}
.h4 {
  font-size: 32px;
}
.h5 {
  font-size: 28px;
}
.p1 {
  font-size: 24px;
}
.p2 {
  font-size: 20px;
}
.p3 {
  font-size: 18px;
}
.p4 {
  font-size: 16px;
}
.p5 {
  font-size: 14px;
}
header.el-header {
  padding: 0;
}
.el-dropdown-menu__item .p2 {
  color: #333;
}
.el-dropdown-menu__item .p4 {
  color: #666;
}
.el-main {
  padding: 0 !important;
  overflow: initial !important;
}
.el-footer {
  background: url("assets/footer_pic_bg.png") 100%;
  max-height: 384px;
}
.g-redDiv {
  width: 10px;
  height: 60px;
  background: rgba(212, 52, 58, 1);
  margin-right: 3%;
  vertical-align: top;
  display: inline-block;
}
.pagina>.el-pager>li.active {
  color: #D4343A;
  cursor: default;
  border: 1px solid #D4343A;
}
.pagina .el-pager li{
  border: 1px solid #333;
  margin: 0 10px ;
  width: 70px;
  height: 70px;
  line-height: 70px;
}
.pagina .el-pager li.active+li{
  border-left: 1px solid #333;
}
.pagina .el-pager li:hover{
  color: #D4343A;
}
.pagina>.btn-next,.pagina>.btn-prev{
  width: 70px;
  height: 70px;
  line-height: 70px;
  border: 1px solid #333;
}
.pagina>button:disabled {
  border: 1px solid #999;
}
.pagina>.btn-next:hover , .pagina>.btn-prev:hover{
  color: #D4343A
}

.form .el-form-item__label{
  font-size: 24px;
  color: #333333;
}
.form .wid .el-input__inner{
  height: 70px;
  font-size: 24px;
  padding: 17px 30px;
  caret-color:red;
}
.form .area .el-textarea__inner{
  height: 250px;
  font-size: 24px;
  padding: 17px 30px;
  font-family:Arial;
  caret-color:red;
}

.form .wid .el-input__inner:focus{
  border: 1px solid #333;
}

@media (max-width: 1500px) {
  .nav .shares {
    display: none;
  }
  footer.el-footer {
    max-height: 500px;
    height: auto !important;
    background-size: cover;
  }
  .el-footer .footer-view div.line {
    display: block;
  }
  .el-footer .footer_logo {
    width: 50px;
    margin-right: 0;
  }
  .el-footer .footer-view {
    width: 90%;
    margin: 0 5%;
  }
  .el-footer .footer-left {
    width: calc(100% - 50px);
  }
  .el-footer .footer-left p {
    font-size: 13px;
  }
  .el-footer .footer-right {
    position: initial;
    width: 100%;
    /* box-sizing: border-box; */
    text-align: center;
  }
  .el-footer .footer-right a {
    font-size: 15px;
    margin: 0;
    line-height: 44px;
  }
  .el-footer .footer-bottom {
    position: relative;
    top: 0;
    left: 0;
    /* width: 113%; */
    margin: 40px auto 0 auto;
    text-align: center;
    transform: translateX(0);
  }
  .el-footer .footer-bottom span.copyright {
    font-size: 10px;
    /* position: absolute;
    bottom: 15px */
  }
  .el-footer .footer-bottom a {
    font-size: 12px;
  }
  .copyright-link {
    position: relative;
    display: block;
    top: -50px;
    left: 50%;
    transform: translateX(-50%);
  }

  .pagina{
    display: block;
  }
}
@media (max-width: 750px) {
  .header-box .nav {
    height: 20vw;
  }
  .nav .nav-view {
    display: none;
  }
  .nav .header-logo {
    margin: 5px -20px 0 10px;
  }
  .nav .header-logo img{
    width: 50px
  }
  .nav .shares {
    /* float: left; */
    display: inline-block;
    transform: scale(0.6);
    position: absolute;
    top: -20px;
    left: 25px;
  }
  .nav .header-search {
    display: none;
  }
  .header-box .lang {
    display: none;
  }
  .hamburger.el-dropdown {
    line-height: 1;
  }
  .nav div.mini-nav {
    position: absolute;
    top: 20px;
    right: 10px;
    display: inline-block;
    width: 50px;
  }
  .main .carousel {
    height: 50vw
  }
  .main .carousel .carousel-indicator {
    left: 14px;
    bottom: 50%;
  }
  .main .carousel .carousel-indicator-view {
    width: 16px;
    height: 16px;
  }
  .main .carousel .carousel-indicator-view.carousel-indicator-view-key{
    font-size: 10px;
    line-height: 16px;
    bottom: 50%;
  }
  .main .carousel .el-carousel{
    height: 50vw;
    left: 12vw;
    top: 0
  }
  .pagina{
    display: none;
  }
}
</style>
