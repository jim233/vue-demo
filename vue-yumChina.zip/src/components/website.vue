<template>
  <div class="wrap">
    <p class="tit">网址导航 </p>
    <div class="div">
      <router-link to="/" class="secTit">关于百胜中国</router-link>
      <router-link to="/companyIntro">公司简介</router-link>
      <router-link to="/brand">品牌家族</router-link>
      <router-link to="/honor">公司荣誉</router-link>
    </div>
    <div class="div">
      <router-link to="/respIndex" class="secTit">企业责任</router-link>
      <router-link :to="{ path:'/respMain',query: { nav:0,secNav:0 }}">以食为天</router-link>
      <router-link :to="{ path:'/respMain',query: { nav:1,secNav:0 }}">以人为本</router-link>
      <router-link :to="{ path:'/respMain',query: { nav:2,secNav:0 }}">以爱为先</router-link>
      <router-link :to="{ path:'/respMain',query: { nav:3,secNav:0 }}">以绿为源</router-link>
    </div>
    <div class="div">
      <router-link to="/newsCenter/0" class="secTit">新闻中心</router-link>
      <router-link to="/newsCenter/0">新闻稿</router-link>
      <router-link to="/newsCenter/1">媒体报道</router-link>
    </div>
    <div class="div">
      <a class="secTit">企业招募</a>
    </div>
    <div class="div">
      <router-link to="/joinIn" class="secTit">品牌加盟</router-link>
    </div>
    <div class="div">
      <a class="secTit">投资者关系</a>
    </div>
  </div>
</template>
<script>
export default {
  name: "website",
};
</script>
<style scoped>
.div .secTit{
  color: #333;
}
.div{
  width: 16.6%;
  display: inline-block;
  vertical-align: top;
}
.div a{
  margin:30px 0;
  display: block;
  color: #666;
}
.tit {
  font-family: SourceHanSansSC-Medium;
  font-size: 36px;
  letter-spacing: 0;
  line-height: 54px;
  padding-bottom: 20px;
  border-bottom: 1px solid #ccc;
  margin-bottom: 30px;
}
.wrap {
  padding: 6% 15.625%;
  min-height: 400px;
  box-sizing: border-box;
  font-family: SourceHanSansSC-Regular;
  font-size: 24px;
  letter-spacing: 0;
  color: #333;
}
</style>


