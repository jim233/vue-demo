<template>
  <div>
    <Header name='品牌加盟' nameEn='FRANCHISE OPPORTUNITIES'></Header>
    <div class="con wrapFont">
      <div style="width:30%;display: inline-block;vertical-align: top;">
        <div class="g-redDiv"></div>
        <span class="titFont">期待与您合作</span>
      </div>
      <div class="content">
        <p>亲爱的朋友:</p>
        <p style="margin:20px 0">百胜中国非常欢迎志同道合的伙伴成为我们的特许经营加盟商，共同开创美好的未来。</p>
        <p style="margin-bottom:20px;">百胜中国的特许经营项目为其特许经营商提供了强大系统支持的机会。这样的机会是当您从一家国际性大型机构获得商标、操作、系统和营销方面支持的同时，拥有从属于您自己的公司，并获得成就感和利润。我们深信，在我们专业的领导与国际品牌质量的保证下，加入成为我们的特许经营加盟商，将为您自己开创出一个不一样的成就人生。</p>
        <p>目前，百胜中国开放了肯德基、必胜客和小肥羊品牌的特许经营加盟。您可以点击下面入口进入网页，阅读我们的加盟信息。我们真诚地期待与您的合作！</p>

        <div style="margin:100px 0 82px;">
          <img src="../assets/pic_brands_logo_kfc.png" alt="" class="img">
          <img src="../assets/bsk.png" alt="" class="img" style="margin:0 18%">
          <img src="../assets/pic_brands_logo_littlesheep.png" alt="" class="img">
        </div>
        <div class="join">
          <img src='../assets/phone.png' />
          <span>加盟咨询电话</span>
          <p>4008-323-323</p>
        </div>

        </div>

      </div>
    </div>
</template>
<script>
import Header from "./about/head.vue";
export default {
  name: "joinIn",
  components: {
    Header
  }
};
</script>
<style scoped>
.join img{
  width: 4.2%;
  vertical-align: top;
  margin-right: 10px
}
.join span {
  font-family: SourceHanSansSC-Regular;
  font-size: 30px;
  line-height: 36px;
  vertical-align: top
}
.join {
  color: #333333;
  letter-spacing: 0;

  font-family: Roboto-Regular;
  font-size: 60px;
  line-height: 60px;
}
.img {
  width: 18%;
}
.wrapFont {
  font-family: SourceHanSansSC-Regular;
  font-size: 24px;
  color: #666666;
  letter-spacing: 0;
  text-align: justify;
  line-height: 48px;
}
.con {
  padding: 2% 10%;
  min-height: 100px;
}
.content {
  width: 70%;
  display: inline-block;
  vertical-align: top;
  margin-bottom: 10%;
}
.titFont {
  font-family: SourceHanSansSC-Medium;
  font-size: 45px;
  color: #333333;
  display: inline-block;
  vertical-align: top;
}
</style>


