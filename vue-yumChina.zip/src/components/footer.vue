<template>
    <div class="footer-view">
      <div class="contact">
        <img :src="logo" alt="百胜logo" class="footer_logo">
        <div class="footer-left">
            <p>{{$t('addr')}}：{{$t('addrInfo')}}</p>
            <p>{{$t('emil')}}：200030</p>
            <p>{{$t('tell')}}：(86 21) 2407-7777</p>
            <p>{{$t('fax')}}：(86 21) 2407-8888</p>
        </div>
      </div>
      <div class="line"></div>
      <div class="footer-right">
          <router-link to="/notes">{{$t('supplier')}}</router-link>
          <router-link to="/website">{{$t('net')}}</router-link>
          <a href="/">YUM! BRANDS</a>
      </div>
      <div class="line"></div>
      <div class="footer-bottom">
            <span class="copyright">{{$t('copyright')}}</span>
            <a href="/" class="record-link">{{$t('copyrightInfo')}} </a>
            <span class="copyright-link">
              <router-link to="/legal">{{$t('legal')}}</router-link>
              <span class="footer-line">|</span>
              <router-link to="/statement">{{$t('privacy')}}</router-link>
            </span>
      </div>
    </div>    
</template>
<script>
import logo from "@/assets/pic_footer_logo.png";

export default {
  data() {
    return {
      logo: logo
    };
  }
};
</script>
<style scoped>
.footer-view {
  position: relative;
  box-sizing: inherit;
  width: 80%;
  max-width: 1570px;
  height: 100%;
  margin: 0 auto;
  padding-top: 4.1vw;
}
.contact {
  display: inline;
}
.footer_logo {
  float: left;
  margin-right: 62px;
}
.footer-left {
  display: inline-block;
  width: 800px;
}
.footer-right {
  position: absolute;
  top: 4.1vw;
  right: 0;
  width: 280px;
}
.footer-left p,
.footer-right a {
  display: block;
  color: white;
  font-size: 24px;
}
.footer-left p {
  margin: 0;
  line-height: 40px;
}
.footer-right a {
  margin-bottom: 44px;
}
.footer-bottom {
  display: block;
  margin: 80px auto 0 auto;
  text-align: center;
}
.footer-bottom span,
.footer-bottom a {
  font-size: 18px;
  color: white;
}
.record-link {
  margin-right: 50px;
}
.footer-line {
  margin: 0 15px;
}
.footer-view div.line {
  display: none;
  width: 100%;
  height: 1px;
  margin: 10px auto;
  background-color: rgba(255, 255, 255, 0.3);
}
</style>
