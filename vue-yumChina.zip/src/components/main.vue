<template>
    <div class="main">
        <div class="carousel">
            <!-- <span class="demonstration">默认 Hover 指示器触发</span> -->
            <el-carousel indicator-position="none" height="45.875vw" :autoplay="false" v-on:change="carousel_eve" ref="carousel_1">
                <el-carousel-item v-for="(item,key,index) in carousel_list" :key="item" name="index">
                    <img :src="item" :alt="key">
                    <span style="display:none">{{index}}</span>
                </el-carousel-item>
            </el-carousel>
            <div class="carousel-indicator">
                <span v-for="(item,key,index) in carousel_list" 
                :key="item" 
                @click="setActiveItem2(index)" 
                :class="['carousel-indicator-view',index===carousel_index?'carousel-indicator-view-key':'']">{{"0" + (index + 1)}}</span>
            </div>
            <img :src="carousel_bg" alt="" class="carousel_bg">
        </div>
        <div class="news">
            <div class="news-left-line">
                <span class="line"></span>
                <span class="p1">最新动态</span>
            </div>
            <div class="news-left">
                <h2 class="h2">百胜中国在上海再推出两家塔可贝尔餐厅</h2>
                <p class="p1">首次推出专属晚间菜单以及送餐到桌服务，东西合璧的独特餐厅设计，让餐厅完美融入社区。</p>
                <a href="/" class="news-link">了解更多<i class="el-icon-back"></i></a>
            </div>
            <div class="news-right">
                <div class="news-right-view">
                    <a href="/" class="news-right-link" v-for="item in 6" :key="item"></a>
                </div>
                <div class="news-right-click">
                    <i class="p1 el-icon-arrow el-icon-arrow-left"></i>
                    <i class="p1 el-icon-arrow el-icon-arrow-right"></i>
                </div>
            </div>
        </div>
        <div class="weibo-view">
            <div class="news-left-line">
                <span class="line"></span>
                <span class="p1">微博动态</span>
                <img src="@/assets/ic_share_weibo.png">
            </div>
            <div class="weibo-list-view">
                <div class="weibo-list" v-for="item in 4" :key="item">
                <img src="@/assets/home_pic_weibo3.png">
                    <div class="weibo-list-right">
                        <div class="weibo-list-right-top">
                            <img src="@/assets/pic_brands_logo_littlesheep.png" class="weibo-header">
                            <span class="p1">小肥羊</span>
                            <img src="@/assets/ic_weibo_v.png" alt="">
                        </div>
                        <div class="weibo-list-right-content p2">#元宵节#  出个灯谜，各位大神来猜猜是什么？快转发本条微博说出灯谜谜底并@三位好…</div>
                        <div class="weibo-list-time p3">2018-05-07  19:57</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="weibo-page">
            <i class="p1 el-icon-arrow el-icon-arrow-left"></i>
            <i class="p1 el-icon-arrow el-icon-arrow-right"></i>
        </div>
        <div class="yum-family">
            <div class="yum-family-top">
                <div class="yum-family-top-left">
                    <h2 class="h2">品牌家族</h2>
                    <p class="p1">百胜中国同时运营多个在中国的领先餐饮品牌，包括肯德基、必胜客、必胜客宅急送、东方既白与小肥羊。这些品牌已经充分融入中国的流行文化与我们顾客的日常生活之中。</p>
                </div>
                <img src="@/assets/home_pic_brand.png">
            </div>
            <div class="yum-family-view">
                <a href=""  v-for="item in 5" :key="item">
                    <img src="@/assets/pic_brands_logo_kfc.png">
                </a>
            </div>
        </div>
    </div>
</template>
<script>
import carousel_list_1 from "@/assets/carousel/home_pic_banner.png";
import carousel_list_2 from "@/assets/carousel/2.jpg";
import carousel_list_3 from "@/assets/carousel/3.jpg";
import carousel_list_4 from "@/assets/carousel/4.jpg";
import carousel_bg from "@/assets/carousel_bg.png";

export default {
  data() {
    return {
      carousel_list: {
        carousel_list_1,
        carousel_list_2,
        carousel_list_3,
        carousel_list_4
      },
      carousel_bg: carousel_bg,
      carousel_index: 0
    };
  },
  methods: {
    carousel_eve(newkey) {
      this.carousel_index = newkey;
    },
    setActiveItem2(index) {
      this.$refs.carousel_1.setActiveItem(index);
    }
  }
};
</script>

<style>
@import "../css/news.css";
@import '../css/newsM.css';
.carousel {
  width: 100%;
  max-width: 1920px;
  height: 46.875vw;
  position: relative;
  /* overflow: hidden; */
}
.carousel .el-carousel {
  width: 81.2%;
  height: 45.875vw;
  position: absolute;
  top: 20px;
  left: 10vw;
}
.carousel .carousel_bg {
  position: absolute;
  height: 100%;
  top: 4vw;
  right: -1vw;
}
.carousel .carousel-indicator {
  position: absolute;
  left: 3%;
  top: 35%;
  width: 58px;
  text-align: center;
  display: flex;
  display: -webkit-flex;
  flex-direction: column;

  justify-content: center;
}
.carousel .carousel-indicator .carousel-indicator-view {
  display: block;
  width: 58px;
  height: 58px;
  border-radius: 50%;
  background-color: #ccc;
  font-size: 0;
  line-height: 58px;
  transform: scale(0.2);
}
.carousel .carousel-indicator .carousel-indicator-view-key {
  background: no-repeat;
  font-family: Roboto-MediumItalic;
  font-size: 40px;
  color: #333333;
  letter-spacing: 0;
  text-align: center;
  line-height: 58px;
  font-style: italic;
  font-weight: bold;
  transform: scale(1);
}
.el-main {
  width: 100%;
  max-width: 1920px;
  margin: 0 auto;
}
.el-carousel__item img{
    width: 100%
}
@media (max-width: 750px) {
  .el-main{
    margin-top: 20vw;
  }
  .main .carousel .carousel-indicator{
    left: 0;
    bottom: 30%;
    width: 10%;
  }
  .carousel .carousel-indicator .carousel-indicator-view{
    width: 10vw;
    height: 10vw;
    line-height: 10vw;
  }
}
</style>

