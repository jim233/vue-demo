<template>
  <div class="wrap">
    <div class="head">
      <img src="../../assets/notesBgc.png" class="bgc" alt="">
      <div class="font">
        <p>百胜中国供应商吹哨人</p>
        <p class="fontCon">我们承诺严格监管百胜中国供应商，杜绝因不规范形成食品安全或质量隐患的行为</p>
      </div>
    </div>
    <div class="con">
      <p class="tit">吹哨人须知</p>
      <div class="content">
        <div v-for="(item,index) in list" :key="index">
          <p v-for="(i,j) in item" :key="j" :class="j==0?'secTit':'marL'">{{i}}</p>
        </div>
      </div>
      <div class="radio">
        <div class="select" @click="change" ></div>
        <span @click="change">本人已阅读、知晓并同意《吹哨人须知》的内容</span>
      </div>
      <div class="create" @click="create">
        创建举报
      </div>
    </div>
  </div>
</template>
<script>
import list from '../../json/note.js';
export default {
  name:'notes',
  data(){
    return{
      list:list,
      select:false,
    }
  },
  methods:{
    change(){
      this.select = !this.select
    },
    create(){
      this.$router.push('/info')
    }
  }
}
</script>
<style scoped>
.create{
  width: 280px;
  height: 70px;
  line-height: 70px;
  text-align: center;
  margin:100px auto;
  background: #FFFFFF;
  border: 1px solid #333333;
  font-size: 24px;
  color: #333333;
}
.select{
  border: 1px solid #999;
  width: 24px;
  height: 24px;
  display: inline-block;
  border-radius: 4px;
  margin-right: 10px;
  vertical-align: middle;
}
.radio{
  margin:30px 50px;
}
.marL{
  margin-left: 5%;
}
.secTit{
  color: #333333;
  margin-bottom: 30px;
}
.content{
  background: #F5F5F5;
  width: 100%;
  max-height: 700px;
  padding: 50px;
  box-sizing: border-box;
  overflow: auto;
  font-family: SourceHanSansSC-Regular;
  font-size: 24px;
  color: #666666;
  letter-spacing: 0;
  text-align: justify;
  line-height: 48px;
}
.tit{
  font-size: 36px;
  color: #333333;
  margin:60px 0;
}
.fontCon{
  font-size:36px;
  margin-top:20px;
}
.font{
  width: 100%;
  height: 100%;
  position: absolute;
  top:50%;
  transform:translate(0,-25%);
  -webkit-transform:translate(0,-25%);
  -moz-transform:translate(0,-25%);
  -ms-transform:translate(0,-25%);
  -o-transform:translate(0,-25%);
  text-align: center;
  color: #fff;
  font-family: SourceHanSansSC-Medium;
  font-size: 80px;
}
.bgc{
  width: 100%;
}
.head{
  position: relative;
}
.con{
  padding: 0 14%;
  min-height: 400px;
  box-sizing: border-box;
  font-family: SourceHanSansSC-Regular;
  font-size: 24px;
  color: #666666;
  letter-spacing: 0;
}
</style>


