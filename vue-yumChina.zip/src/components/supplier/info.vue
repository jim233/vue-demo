<template>
  <div class="wrap">
    <div class="head" v-if="!show">
      <img src="../../assets/notesBgc.png" class="bgc" alt="">
      <div class="font">
        <p>百胜中国供应商吹哨人</p>
        <p class="fontCon">我们承诺严格监管百胜中国供应商，杜绝因不规范形成食品安全或质量隐患的行为</p>
      </div>
    </div>
    <div class="con" v-if="!show">
      <p class="tit">请填写举报内容<span>（以下带 * 号为必填内容）</span></p>

      <el-form ref="form" label-position="left" :model="form" label-width="170px" class="form">
        <el-form-item label="联系方式">
          <el-input v-model="form.name" class="wid" placeholder="请填写您的姓名"></el-input>
          <span class="start">*</span>
        </el-form-item>
        <el-form-item label=" ">
          <el-input v-model="form.tell" class='wid' placeholder="请填写您的电话"></el-input>
        </el-form-item>
        <el-form-item label=" ">
          <el-input v-model="form.emil" class='wid' placeholder="请填写您的邮箱  example@example.com"></el-input>
          <span class="start">*</span>
        </el-form-item>
        <el-form-item label="  ">
          <el-input v-model="form.company" class='wid' placeholder="请填写您的单位"></el-input>
          <span class="start">*</span>
        </el-form-item>
        <el-form-item label="举报对象 " class="area">
          <el-input type="textarea" v-model="form.report" placeholder="请注明单位、涉及人员及职务"></el-input>
        </el-form-item>
        <el-form-item label="举报内容" class="area">
          <el-input type="textarea" v-model="form.reportInfo" placeholder="请注明事由、时间、地点、具体细节等"></el-input>
        </el-form-item>
      </el-form>

      <div class="create" @click="submit">
        提交举报
      </div>
    </div>

    <div class="con successInfo" v-if="show">
      <div class="success">
        <img src="../../assets/submitSuccess.png" class="sucImg" alt="">
        <span>提交成功！</span>
      </div>
      <p>举报编号：EA2236789000912</p>
      <p>感谢您使用“百胜中国供应商吹哨人网站”，我们会有专人通过您留下的邮箱与您联系</p>
      <div class="create" @click="$router.push('/')">
        返回百胜中国首页
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name:'info',
  data(){
    return{
      form:{
        name:'',
        tell:'',
        emil:'',
        company:'',
        report:'',
        reportInfo:'',
      },
      show:false,
    }
  },
  methods:{
    submit(){
      this.show = true
    }
  }
}
</script>
<style scoped>
.sucImg{
  width: 40px;
  vertical-align: middle;
  margin-right: 10px;
}
.successInfo p{
  margin: 7.5px 0;
}
.wrap .successInfo{
  color: #333333;
  text-align: center;
}
.success{
  font-size: 36px;
  margin-bottom: 40px;
}
.create{
  width: 280px;
  height: 70px;
  line-height: 70px;
  text-align: center;
  margin:100px auto;
  background: #FFFFFF;
  border: 1px solid #333333;
  font-size: 24px;
  color: #333333;
}
.start{
  color: #D4343A;
  font-size: 24px;
  margin-left: 14px;
}
.area{
  margin-top: 60px;
}
.el-form-item{
  margin-bottom: 40px;
}
.wid{
  max-width: 600px;
}
.form{
  margin:60px 0;
}
.tit{
  font-family: SourceHanSansSC-Medium;
  font-size: 36px;
  color: #333333;
}
.tit span{
  margin-left: 13px;
  font-size: 24px;
  font-family: SourceHanSansSC-Regular;
}
.fontCon{
  font-size:36px;
  margin-top:20px;
}
.font{
  width: 100%;
  height: 100%;
  position: absolute;
  top:50%;
  transform:translate(0,-25%);
  -webkit-transform:translate(0,-25%);
  -moz-transform:translate(0,-25%);
  -ms-transform:translate(0,-25%);
  -o-transform:translate(0,-25%);
  text-align: center;
  color: #fff;
  font-family: SourceHanSansSC-Medium;
  font-size: 80px;
}
.bgc{
  width: 100%;
}
.head{
  position: relative;
}
.con{
  padding: 4% 15.625%;
  min-height: 400px;
  box-sizing: border-box;
  font-family: SourceHanSansSC-Regular;
  font-size: 24px;
  color: #CCCCCC;
  letter-spacing: 0;
  text-align: justify;
}
</style>


