<template>
    <div class="header-box">
        <div class="lang">
            <span @click="changeLang('cn')" :class="lang == 'cn'?'':'lang-cut'">中文</span>
            <span class="lang-cut">/</span>
            <span @click="changeLang('en')" :class="lang == 'en'?'':'lang-cut'">English</span>
        </div>
        <div class="nav">
            <a href="/" class="header-logo"><img :src=logo alt="百胜logo"></a>
            <div class="nav-view">
              <el-dropdown>
                  <span class="el-dropdown-link">
                    {{ $t("about") }}
                    <i class="el-icon-caret-bottom el-icon--right"></i>
                  </span>
                  <el-dropdown-menu slot="dropdown">
                      <el-dropdown-item><router-link to='/companyIntro' class="p2">{{$t('companyIntroSec')}}</router-link></el-dropdown-item>
                      <el-dropdown-item><router-link to="/brand" class="p2">{{$t("brandFamilySec")}}</router-link ></el-dropdown-item>
                      <el-dropdown-item><router-link to="/honor" class="p2">{{$t("companyHonorsSec")}}</router-link></el-dropdown-item>
                  </el-dropdown-menu>
              </el-dropdown>
              <el-dropdown>
                  <router-link class="el-dropdown-link" to='/respIndex'>
                      {{$t('responsibility')}} <i class="el-icon-caret-bottom el-icon--right"></i>
                  </router-link>
                  <el-dropdown-menu slot="dropdown">
                      <el-dropdown-item>
                          <p class="p2" @click="jump(0,0)">{{$t('foodSec')}}</p>
                          <p class="p4" @click="jump(0,1)">健康与营养</p>
                          <p class="p4" @click="jump(0,2)">质量与安全</p>
                      </el-dropdown-item>
                      <el-dropdown-item>
                          <p class="p2" @click="jump(1,0)">{{$t('peopleSec')}} </p>
                          <p class="p4" @click="jump(1,1)">核心价值观和文化</p>
                          <p class="p4" @click="jump(1,2)">人员能力第一：主导自我发展，提携他人成长</p>
                          <p class="p4" @click="jump(1,3)">多元化和机会平等：打造包容的文化，展现公司和顾客的多元化</p>
                      </el-dropdown-item>
                      <el-dropdown-item>
                          <p class="p2" @click="jump(2,0)">{{$t('loveSec')}}</p>
                          <p class="p4" @click="jump(2,1)">捐一元 · 献爱心 · 送营养</p>
                          <p class="p4" @click="jump(2,2)">肯德基曙光基金</p>
                          <p class="p4" @click="jump(2,3)">肯德基小候鸟基金</p>
                          <p class="p4" @click="jump(2,4)">肯德基天使餐厅</p>
                          <p class="p4" @click="jump(2,5)">肯德基三人篮球赛</p>
                          <p class="p4" @click="jump(2,6)">必胜客“悦读食光” 公益阅读项目</p>
                          <p class="p4" @click="jump(2,7)">必胜客扶业计划</p>
                      </el-dropdown-item>
                      <el-dropdown-item>
                          <p class="p2" @click="jump(3,0)">{{$t('greenSec')}}</p>
                      </el-dropdown-item>
                  </el-dropdown-menu>
              </el-dropdown>
              <el-dropdown placement="bottom-start">
                  <router-link to="/newsCenter/0" class="el-dropdown-link">
                      {{$t('news')}}<i class="el-icon-caret-bottom el-icon--right"></i>
                  </router-link>
                  <el-dropdown-menu slot="dropdown">
                      <el-dropdown-item><router-link to="/newsCenter/0" class="p2">{{$t('new')}}</router-link></el-dropdown-item>
                      <el-dropdown-item><router-link to="/newsCenter/1" class="p2">{{$t('report')}}</router-link></el-dropdown-item>
                      <!-- <el-dropdown-item><p class="p2">科普与辟谣</p></el-dropdown-item>
                      <el-dropdown-item><p class="p2">多媒体中心</p></el-dropdown-item> -->
                  </el-dropdown-menu>
              </el-dropdown>
              <span class="el-dropdown-link">{{$t('recruit')}}</span>
              <router-link to="/joinIn" class="el-dropdown-link">{{$t('brandJoin')}}</router-link>
              <span class="el-dropdown-link">{{$t('investors')}}</span>
            </div>
            <el-button @click="search_show = !search_show" icon="el-icon-search" class="header-search">{{$t('search')}}</el-button>
            <div class="shares">
                <div class="shares_item shares_num">
                    <span class="h5">37.00</span>
                    <span class="p5">YUMC-NYSE</span>
                </div>
                <span class="line"></span>
                <div class="shares_item shares-time">
                    <span class="h5"><i class="el-icon-caret-top p5"></i>5.47</span>
                    <span class="p5">2018-05-02</span>
                </div>
            </div>
            <div class="mini-nav">
              <i class="el-icon-search p2"></i>
              <el-dropdown class="hamburger">
                <el-button type="primary">
                  <span class="line"></span>
                  <span class="line"></span>
                  <span class="line"></span>
                </el-button>
                <el-dropdown-menu slot="dropdown">
                  <el-dropdown-item>黄金糕</el-dropdown-item>
                  <el-dropdown-item>狮子头</el-dropdown-item>
                  <el-dropdown-item>螺蛳粉</el-dropdown-item>
                  <el-dropdown-item>双皮奶</el-dropdown-item>
                  <el-dropdown-item>蚵仔煎</el-dropdown-item>
                </el-dropdown-menu>
              </el-dropdown>
            </div>
        </div>
        <div class="search-bg">
            <el-collapse-transition>
                <div v-show="search_show">
                    <div class="transition-box">
                        <i class="el-icon-search"></i>
                        <el-input v-model="search_input" :placeholder="$t('tipInput')"></el-input>
                        <el-button @click="search_submit(search_input)">{{$t('search')}}</el-button>
                        <i class="el-icon-close" @click="search_show = !search_show"></i>
                    </div>
                </div>
            </el-collapse-transition>
        </div>
    </div>
</template>
<style scoped>
.lang {
  height: 40px;
  line-height: 40px;
  font-size: 14px;
  text-align: right;
}
.header-box,
.lang {
  max-width: 1920px;
  margin: 0 auto;
}

.lang-cut {
  margin: 0 5px;
}

.lang-cut{
  color: #c3c3c3;
  line-height: 16px;
}
.header-box {
  position: relative;
}
.el-menu--horizontal {
  left: 0;
}
.nav {
  height: 100px;
  position: relative;
}
.header-logo {
  float: left;
  margin-right: 60px;
}
.nav-view {
  display: inline-block;
  width: 60%;
  height: 104px;
  overflow: hidden;
}
.el-dropdown {
  line-height: 100px;
}
.el-dropdown-link {
  font-size: 24px;
  margin-right: 46px;
  cursor: pointer;
  color: #333
}
.el-dropdown-link:hover {
  color: #d4343a;
}
.el-dropdown-menu.el-popper {
  box-sizing: border-box;
  left: 0 !important;
  width: 1920px;
  border-radius: 0;
  border-top: 2px solid #d4343a;
  margin: 0;
  padding: 42px 0 56px 340px;
}
.el-dropdown-menu.el-popper .el-dropdown-menu__item {
  float: left;
  width: 280px;
  padding: 0;
  text-overflow: ellipsis;
}
.el-dropdown-menu.el-popper .el-dropdown-menu__item p {
  margin: 0;
  width: 220px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.el-dropdown-menu.el-popper .el-dropdown-menu__item:hover {
  background: no-repeat;
}
.el-dropdown-menu.el-popper .el-dropdown-menu__item p:hover ,.el-dropdown-menu.el-popper .el-dropdown-menu__item a:hover{
  color: #d4343a;
}
.header-search{
  position: relative;
  top: -50%
}
.shares {
  float: right;
  width: 240px;
  height: 80px;
  margin: 6px 0;
  padding-top: 14px;
}
.shares_item {
  display: inline-block;
  text-align: center;
}
.shares_item span {
  display: block;
}
.shares_item .h5 {
  margin-bottom: 4px;
}
.shares .line {
  position: relative;
  display: inline-block;
  top: -7px;
  margin: 0 24px;
  height: 30px;
  width: 0;
  border-right: 1px solid #545454;
}
.shares-time .p5 {
  color: #545454;
}
.shares-time [class^="el-icon"] {
  position: relative;
  top: -5px;
  left: -5px;
}
.shares-time .el-icon-caret-top {
  color: #d4343a;
}
.search-bg {
  position: absolute;
  top: 40px;
  left: 0;
  width: 100%;
}
.transition-box {
  /* position: absolute;
  top: 0;
  left: 0; */
  width: 100%;
  height: 100px;
  line-height: 100px;
  background: white;
}
.transition-box .el-input {
  width: 1200px;
}

.transition-box .el-icon-search {
  margin-right: 42px;
}
.search-bg input {
  font-size: 24px;
  border: none;
}
.search-bg .el-button.el-button--default {
  width: 140px;
  margin-right: 100px;
}
.hamburger .line {
  display: block;
  height: 2px;
  width: 20px;
  background: #333;
  margin-bottom: 6px
}
.mini-nav{
  display: none
}
.mini-nav .el-icon-search {
  position: relative;
  top: -8px;
  right: 15px;
  color: #333
}
.hamburger .el-button{
  padding: 5px;
  background-color: transparent;
  border: none
}
@media (max-width: 750px){
  .header-box .nav{
    position: fixed;
  }
}
@import '../css/headerM.css';
</style>
<script>
import logo from "@/assets/logo.png";
export default {
  data() {
    return {
      activeIndex: "1",
      activeIndex2: "1",
      logo: logo,
      search_show: false,
      search_input: "",
      lang:localStorage.lang,
    };
  },
  methods: {
    search_submit() {
      this.search_show = !this.search_show;
    },
    jump(nav,secNav){
      this.$router.push({
        path:'/respMain',
        query:{
          nav:nav,
          secNav:secNav
        }
      })
    },
    changeLang(e){
      this.$i18n.locale = e ;
      localStorage.lang = e;
      this.lang = e ;
    }
  }
};
</script>
