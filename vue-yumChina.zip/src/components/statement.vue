<template>
  <div class="wrap">
    <div class="head">
      隐私声明
      <p>本隐私政策更新于：2018年03月</p>
    </div>
    <!-- 1 -->
    <div class="con" v-if="curPage == index+1 " v-for="(item,index) in list" :key="index">
      <p :class="j==0?'tit':''" v-for="(i,j) in item" :key="j">{{i}}</p>
    </div>
    <!-- 分页 -->
    <el-pagination class="pagina" :pager-count="9" :page-size='1' :current-page='curPage' layout="prev, pager, next" :total="9" @current-change='curChange'>
    </el-pagination>
  </div>
</template>
<script>
import list from '../json/statement.js'
export default {
  name: "statement",
  data() {
    return {
      curPage: 1,
      list:list
    };
  },
  methods: {
    curChange(e) {
      this.curPage = e
    }
  }
};
</script>
<style scoped>
.con p {
  margin-top: 24px;
}
.tit {
  color: #333333;
}
.con {
  margin: 5% 0;
  line-height: 48px;
}
.head {
  font-size: 36px;
  color: #333333;
}
.head p {
  font-size: 24px;
  margin-top: 20px;
}
.wrap {
  padding: 6% 15.625%;
  min-height: 400px;
  box-sizing: border-box;
  font-family: SourceHanSansSC-Regular;
  font-size: 24px;
  letter-spacing: 0;
  color: #666;
}
</style>

