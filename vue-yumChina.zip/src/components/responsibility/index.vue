<template>
  <div class="wrap">
    <!-- url='../../assets/repBgc' -->
    <Header nav='4'></Header>
    <div class="con wrapFont">
      <div style="width:30%;display: inline-block;vertical-align: top;">
        <div class="g-redDiv"></div>
        <span class="titFont">概览</span>
      </div>
      <div class="content">
        <p>自从1987年进入中国市场， 百胜中国在不断发展壮大的同时，不忘企业社会责任，始终秉承“回报社会”的宗旨，积极支持慈善事业，让关爱社会成为企业核心价值观之一。20多年来，百胜用于公益方面的捐款已超过5亿元人民币。百胜为公益事业所做的积极贡献也得到了全社会的赞赏和认可，荣获的公益奖项数不胜数。。</p>
        <div class="view">
          百胜全球CSR网站
          <img src="../../assets/return.png">
        </div>
      </div>
    </div>
    <div class="report wrapFont">
      <div style="width:42%;display: inline-block;vertical-align: top;margin-top:10%">
        <div class="g-redDiv"></div>
        <div class="titFont">
          <p>《企业社会责任》</p> 报告
        </div>
      </div>
      <div class="reportRight">
        <img src="../../assets/pic_res_pic_report.png" alt="报道" class="repImg">
        <p>自1987年进入中国市场以来，百胜中国一直致力于促进可持续发展，并在其中贡献自己的力量。 《百胜中国2017年企业社会责任和可持续发展报告》是公司独立上市以来的首份企业社会责任和可持续发展报告。报告在四个章节中，具体呈现百胜中国发挥规模效应与专业优势，创造广泛积极影响力：“以食为天”、“以人为本”、“以爱为先”、“以绿为源”。</p>
        <div class="view down">
          下载报告
          <img src="../../assets/down.png">
        </div>
        <span class="viewHis">查看历史</span>
      </div>
    </div>
    <div class="intro wrapFont" >
      <div class="introLeft" >
        <img src="../../assets/good.png" alt="以食为天" style="width:100%">
        <div class="introCon">
          <span class="introTit">以食为天</span>
          <p>“民以食为天，食以安为先”。均衡膳食和食品安全直接关系到人们的身体健康和社会稳定。百胜中国一直把推动饮食健康、提倡平衡膳食当作是自己义不容辞的社会责任，并在产品开发、普及教育、推动运动等方面做了很多积极努力。作为中国知名的餐饮企业之一，百胜中国一直把均衡膳食和食品安全放在一切工作的首位。</p>
          <div class="more">
            了解更多
            <img src="../../assets/return.png" alt="下一步">
          </div>
        </div>

        <img src="../../assets/love.png" alt="以爱为先" style="width:100%">
        <div class="introCon">
          <span class="introTit">以食为天</span>
          <p>“关爱社会”是百胜企业核心价值观之一，博爱之心是百胜每一位员工关注社会、回馈社会的态度。百胜一直打造“充满博爱之心的企业”，因为我们坚信公益事业是长期持续、不断发展的工作，它需要企业、员工、合作伙伴以及每一位消费者的共同参与。在中国，百胜利用自身的资源和力量已成功倡导了一系列深入人心的公益项目。</p>
          <div class="more">
            了解更多
            <img src="../../assets/return.png" alt="下一步">
          </div>
        </div>
      </div>
      
      <div class="introRight">
        <img src="../../assets/people.png" alt="一人为本" style="width:100%">
        <div class="introCon">
          <span class="introTit">以人为本</span>
          <p>“人才”是百胜最重要的财富。我们信任每一位伙伴，相信每个人都有为团队做出贡献的潜能。我们投入公司资源辅导和发展每一位伙伴的能力。我们积极地追求各种不同的思路来激励他们成为最好的人才，我们为其他同事的成就而庆祝并乐此不疲</p>
          <div class="more">
            了解更多
            <img src="../../assets/return.png" alt="下一步">
          </div>
        </div>

        <img src="../../assets/green.png" alt="一人为本" style="width:100%">
        <div class="introCon">
          <span class="introTit">以绿为源</span>
          <p>百胜一直追求人与环境和谐共生的可持续发展，将环境保护作为企业发展壮大的命脉，积极遵循绿色建筑标准，推进资源节约利用、原材料可持续使用，从而减少对环境的污染，用实质行动为中国的可持续发展贡献力量，与社会共同进步。</p>
          <div class="more">
            了解更多
            <img src="../../assets/return.png" alt="下一步">
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Header from './head.vue'
export default {
  name:'index',
  components:{
    Header
  },
  created(){
  }
}
</script>
<style scoped>

.wrapFont{
  font-family: SourceHanSansSC-Regular;
  font-size: 24px;
  color: #666666;
  letter-spacing: 0;
  text-align: justify;
  line-height: 48px;
}
.intro{
  padding: 5% 10% 2%;
}
.more{
  text-align: right;
  margin-top: 5%;
}
.introTit{
  font-size: 36px;
  color: #333333;
  letter-spacing: 0;
  text-align: left;
  line-height: 36px;
  margin-bottom: 20px;
}
.introCon p{
  min-height: 240px;
}
.introCon{
  width: 85%;
  position: relative;
  top: -100px;
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.12);
  z-index: 5;
  padding: 8%;
  box-sizing: border-box;
  background-color: #fff;
  font-size: 20px;
  line-height: 40px;
}
.introRight{
  width: 49%;
  display: inline-block;
  margin-top:5%;
  vertical-align: top;
}
.introLeft{
  width: 49%;
  display: inline-block;
  margin-right:2%;
  vertical-align: top;
}
.viewHis{
  color: #D4343A;
  position: absolute;
  right: 0;
  bottom:0px
}
.down{
  background-color: #fff
}
.reportRight p{
  margin:4% 0;
}
.repImg{
  width:100%;
}
.reportRight{
  width: 58%;
  display: inline-block;
  vertical-align: top;
  position: relative;
  top: -100px;
}
.report{
  background-color: #f5f5f5;
  min-height: 200px;
  padding: 0 10%;
}
.view {
  width: 32%;
  height: 60px;
  line-height: 60px;
  border: 1px solid #333;
  text-align: center;
  font-size: 24px;
  margin-top: 5%;
  font-family: Roboto-Regular;
  color: #151515;
  letter-spacing: 0;
}
.pad {
  padding: 5% 0;
}
.content {
  width: 70%;
  display: inline-block;
  vertical-align: top;
  margin-bottom: 10%;
}
.titFont {
  font-family: SourceHanSansSC-Medium;
  font-size: 45px;
  color: #333333;
  display: inline-block;
  vertical-align: top;
}
.con {
  padding: 2% 10%;
  min-height: 100px;
}
</style>