<template>
  <div>
    <div class="con wrapFont">
      <div style="width:25%;display: inline-block;vertical-align: top;">
        <div class="g-redDiv"></div>
        <span class="titFont">概览</span>
      </div>
      <div class="content">
        <p v-for='item in list[index]' :key="item">{{item}}</p>
      </div>
    </div>

    <div class="child">
      <img src="../../assets/peopleMore.png" alt="">
      <div class="secNavTit">
        核心价值观和文化
        <img src="../../assets/return.png" class="return" alt="">
      </div>
    </div>
    <div class="child">
      <img src="../../assets/peopleAbiliy.png"  alt="">
      <div class="secNavTit">
        人员能力第一：主导自…
        <img src="../../assets/return.png" class="return" alt="">
      </div>
    </div>
  </div>
</template>
<script>
const list = [
  ['“民以食为天，食以安为先”。均衡膳食和食品安全直接关系到人们的身体健康和社会稳定。百胜中国一直把推动饮食健康、提倡平衡膳食当作是自己义不容辞的社会责任，并在产品开发、普及教育、推动运动等方面做了很多积极努力。作为中国最大的餐饮企业之一，百胜中国一直把均衡膳食和食品安全放在一切工作的首位。自1987年进入中国以来，百胜本着“立足中国，融入生活”的宗旨，不遗余力地在中国打造“从农田到餐桌”的一整套食品安全管理体系，为消费者提供美味、安全和健康的食品。'],
  ['在百胜中国， 45万名员工是推动我们业务持续发展的原动力。我们的企业文化以公平、关爱和自豪感为基石，不断激发员工的潜能，帮助他们成就不凡。我们积极投入资源，确保员工在职业生涯的各个发展阶段获得所需的技能和平台，让他们全身心投入工作并以自己的工作为荣。这一切都践行了百胜中国的使命——让生活更有滋味。',
    '百胜中国是中国最大的雇主之一。我们遍布全国的8100 余家门店拥有45 万余名员工，每天为数以亿计的中国顾客提供服务。我们激励员工用心制作美食、提供优质服务，为顾客带来极佳的体验。',
    '我们引以为豪的是百胜中国为员工提供的系统化培训和发展机会，帮助员工能在公司开创成功的职业生涯。此外， 百胜中国积极营造多元和包容的工作环境，让每位员工平等获得释放自身潜能的机会。'],
  ['“关爱社会”是百胜企业核心价值观之一，博爱之心是百胜每一位员工关注社会、回馈社会的态度。百胜一直打造“充满博爱之心的企业”，因为我们坚信公益事业是长期持续、不断发展的工作，它需要企业、员工、合作伙伴以及每一位消费者的共同参与。在中国，百胜利用自身的资源和力量已成功倡导了一系列深入人心的公益项目。',]
]
export default {
  name:'secNav',
  props:['index'],
  data(){
    return {
      list:list
    }
  }
}
</script>
<style scoped>
.secNavTit .return{
  width: 18px;
  margin-left: 17px;
}
.secNavTit{
  padding:0 40px;
  line-height: 60px;
  height: 60px;
  font-family: SourceHanSansSC-Medium;
  font-size: 36px;
  color: #333333;
  letter-spacing: 0;
  text-align: left;
}
.child{
  display: inline-block;
  vertical-align: top;
  margin-right: 40px;
  box-shadow: 0 0 6px 0 rgba(0,0,0,0.10);
}
.child img{
  width: 500px;
}
p{
  margin-bottom:20px;
}
.wrapFont{
  font-family: SourceHanSansSC-Regular;
  font-size: 24px;
  color: #666666;
  letter-spacing: 0;
  text-align: justify;
  line-height: 48px;
}
.content {
  width: 75%;
  display: inline-block;
  vertical-align: top;
  margin-bottom: 10%;
}
.titFont {
  font-family: SourceHanSansSC-Medium;
  font-size: 45px;
  color: #333333;
  display: inline-block;
  vertical-align: top;
}
.con {
  padding-top: 5%;
  min-height: 100px;
}
</style>