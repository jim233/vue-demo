<template>
  <div>
    <div class="con wrapFont">
      <div>
        <div class="g-redDiv"></div>
        <div class="titFont">多元化和机会平等：打造包容的文化，展现公司和顾客的多元化</div>
        <p class="head">百胜中国深知多元化与机会平等对公司的持续成功至关重要。因此，我们确保打造一个能让员工受到尊重、重视和认可，并能保持个性的工作环境。作为我们的业务重点，提升包容性需要全体员工的共同努力。</p>
      </div>

      <div v-for="(item,index) in list" :key="index" class="content">
        <p v-for="(i,j) in item" :key="i" :class="j ==0?'secTit':''">
          {{i}}
        </p>
      </div>

      <img src="../../assets/peopleOp.png" alt="" class="bgc">
    </div>
  </div>
</template>
<script>
const list = [
  ['公平是百胜中国“以人为本”理念的基本原则之一',
    '我们坚持为员工的职业周期（包括招募、雇用、发展、晋升和报酬）提供平等的机会，使其不受年龄、性别、残疾与否、性取向或其他受法律保护方面的影响。我们主张员工应在专业、安全、无歧视的环境中开展工作，并根据员工的表现进行认可和奖励。',
   '截至2017 年底，百胜中国雇用的女性员工超过27.8 万人，约占员工总数的61.5%。2017 年9 月，百胜中国入选“道富环球性别多元化指数”（SSGA Gender Diversity Index）。该指数由大型美国上市公司组成，致力于通过提高董事会和高管团队的女性成员比例，来消除性别差距，提升女性职场地位。'
  ],[
    '肯德基“天使”餐厅',
    '百胜中国一直努力为特障人士创造就业机会，我们对此引以为豪。通过一项创新的企业社会责任项目――肯德基“天使”餐厅，我们向特障群体提供就业机会。',
    '肯德基“天使”餐厅项目于2012 年启动，就职于“天使”餐厅中的半数员工为聋哑或智力障碍人士。为了便于“天使”员工工作，这些餐厅配备了特殊改造过的设备。例如，我们改造了炸锅的电脑版，除了鸣叫提示功能外，还增加了灯光闪烁来提示操作已经顺利完成。',
    '我们为“天使”餐厅的所有员工提供相关培训，并从餐厅管理团队中挑选人员，与“天使”员工组成搭档。培训部门还基于各类情境和“天使”员工的特点设计了专门的培训方法，以确保这些员工在一个月内具备独立完成工作的能力。餐厅管理团队成员和其他员工也都努力学习手语，确保能和“天使”员工顺畅地沟通。截至2017 年底，公司在19 个城市共开设了20 家肯德基“天使”餐厅。'
  ]
]
export default {
  name:'culture',
  data(){
    return{
      list:list
    }
  }
}
</script>
<style scoped>
.bgc{
  width: 100%;
}
p{
  margin-bottom: 30px;
}
.secTit{
  font-size: 32px;
  color: #333333;
}
.content{
  margin-top: 100px;
}
.head{
  font-family: SourceHanSansSC-Regular;
  font-size: 24px;
  color: #666666;
  letter-spacing: 0;
  text-align: justify;
  line-height: 48px;
  margin-top: 80px;
}
.wrapFont{
  font-family: SourceHanSansSC-Regular;
  font-size: 24px;
  color: #666666;
  letter-spacing: 0;
  text-align: justify;
  line-height: 48px;
}
.titFont {
  width: 95%;
  font-family: SourceHanSansSC-Medium;
  font-size: 60px;
  color: #333333;
  display: inline-block;
  vertical-align: top;
  line-height: 72px;
  margin-top: -10px;
}
.con {
  min-height: 100px;
}
</style>