<template>
  <div>
    <Header :nav='nav'></Header>
    <div class="content">
      <div class="left">
        <div>
          <p class="nav" :class="nav == 0 && secNav == 0  ?'fontRed':''" @click="jump(0,0)">以食为天</p>
          <div class="secNav" v-if="nav == 0">
            <p :class="nav == 0 && secNav == 1  ?'fontRed':''" @click="jump(0,1)">- 营养与健康</p>
            <p :class="nav == 0 && secNav == 2  ?'fontRed':''" @click="jump(0,2)">- 质量与安全</p>
          </div>
        </div>
        <div>
          <p class="nav" :class="nav == 1 && secNav == 0  ?'fontRed':''" @click="jump(1,0)">以人为本</p>
          <div class="secNav" v-if="nav == 1">
            <p :class="nav == 1 && secNav == 1  ?'fontRed':''" @click="jump(1,1)">- 核心价值观和文化</p>
            <p :class="nav == 1 && secNav == 2  ?'fontRed':''" @click="jump(1,2)">- 人员能力第一：主导自我发展，提携他人成长</p>
            <p :class="nav == 1 && secNav == 3  ?'fontRed':''" @click="jump(1,3)">- 多元化和机会平等：打造包容的文化，展现公司和顾客的多元化</p>
          </div>
        </div>
        <div>
          <p class="nav" :class="nav == 2 && secNav == 0  ?'fontRed':''" @click="jump(2,0)">以爱为先</p>
          <div class="secNav" v-if="nav == 2">
            <p :class="nav == 2 && secNav == 1  ?'fontRed':''" @click="jump(2,1)">- 捐一元·献爱心·送营养</p>
            <p :class="nav == 2 && secNav == 2  ?'fontRed':''" @click="jump(2,2)">- 肯德基曙光基金</p>
            <p :class="nav == 2 && secNav == 3  ?'fontRed':''" @click="jump(2,3)">- 肯德基小候鸟基金</p>
            <p :class="nav == 2 && secNav == 4  ?'fontRed':''" @click="jump(2,4)">- 肯德基天使餐厅</p>
            <p :class="nav == 2 && secNav == 5  ?'fontRed':''" @click="jump(2,5)">- 肯德基三人篮球赛</p>
            <p :class="nav == 2 && secNav == 6  ?'fontRed':''" @click="jump(2,6)">- 必胜客“悦读食光”公益阅读项目</p>
            <p :class="nav == 2 && secNav == 7  ?'fontRed':''" @click="jump(2,7)">- 必胜客扶业计划</p>
          </div>
        </div>
        <div>
          <p class="nav" :class="nav == 3 && secNav == 0  ?'fontRed':''" @click="jump(3,0)">以绿为源</p>
        </div>
      </div>
      <div class="right">
        <secNav v-if='secNav == 0 && nav != 4' :index='nav'></secNav>
        <culture v-if='nav == 1 && secNav == 1'></culture>
        <chance  v-if='nav == 1 && secNav == 2'></chance>
        <personnel v-if='nav == 1 && secNav == 3'></personnel>
      </div>
    </div>
  </div>
</template>
<script>
import Header from "./head.vue";
import secNav from './secNav.vue';
import culture from './culture.vue'
import chance from './chance.vue'
import personnel from './personnel.vue'
export default {
  components: {
    Header,secNav,culture,chance,personnel
  },
  data() {
    return {
      nav: this.$route.query.nav,
      secNav: this.$route.query.secNav,
    };
  },
  methods:{
    jump(nav,secNav){
      this.nav = nav 
      this.secNav = secNav
    }
  },
  watch: {
    $route(){
      this.nav = this.$route.query.nav
      this.secNav = this.$route.query.secNav
    }
  }
};
</script>
<style scoped>
p{
  cursor: pointer;
}
.nav {
  margin-top: 50px;
}
.secNav p {
  padding:0 0 20px 10%;
}
.secNav {
  font-family: SourceHanSansSC-Regular;
  font-size: 20px;
  color: #666666;
  margin-top:20px
}
.content .fontRed {
  color: #d4343a;
}
.right {
  width: 82.3%;
  display: inline-block;
  vertical-align: top;
  box-sizing: border-box;
  padding: 6% 8%;
  min-height: 200px;
  margin-left: 17.7%;
  min-height: 1500px;
}
.left {
  width: 17.7%;
  background-color: #f5f5f5;
  position: absolute;
  height: 100%;
  padding: 4.3% 1% 0 4.2%;
  box-sizing: border-box;
  display: inline-block;
  vertical-align: top;
  font-family: SourceHanSansSC-Regular;
  font-size: 30px;
  color: #666666;
}
.content {
  width: 100%;
  position: relative;
  font-family: SourceHanSansSC-Medium;
}
</style>

