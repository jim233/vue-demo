<template>
  <div class="title head">
    <div class="carousel">
      <el-carousel indicator-position="none" height="45.875vw" :autoplay="false" v-on:change="carousel" ref="carousel">
        <el-carousel-item v-for="(item,key,index) in carousel_list" :key="item" name="index">
          <img :src="item" :alt="key">
          <span style="display:none">{{index}}</span>
        </el-carousel-item>
      </el-carousel>
      <div class="carousel-indicator">
        <span v-for="(item,key,index) in carousel_list" :key="item" @click="setActiveItem(index)" :class="['carousel-indicator-view',index===carousel_index?'carousel-indicator-view-key':'']">{{"0" + (index + 1)}}</span>
      </div>
    </div>
    <div class="title">
      <img :src="titleData[nav].url" class="titleImg" alt="标题">
      <div class="titCom">
        <p class="cn">{{titleData[nav].name}}</p>
        {{titleData[nav].nameEn}}
      </div>
    </div>
  </div>
</template>
<script>
import carousel_list_1 from "@/assets/carousel/home_pic_banner.png";
import carousel_list_2 from "@/assets/carousel/2.jpg";
import carousel_list_3 from "@/assets/carousel/3.jpg";
import carousel_list_4 from "@/assets/carousel/4.jpg";
import carousel_bg from "@/assets/carousel_bg.png";
const titleData = [{
  name:'以食为天',
  nameEn:'FOOD',
  url:require('../../assets/headTitBgc_1.png')
},{
  name:'以人为本',
  nameEn:'PEOPLE',
  url:require('../../assets/headTitBgc.png')
},{
  name:'以爱为先',
  nameEn:'COMMUNITY',
  url:require('../../assets/headTitBgc_3.png')
},{
  name:'以绿为源',
  nameEn:'Environment',
  url:require('../../assets/headTitBgc_4.png')
},{
  name:'企业责任',
  nameEn:'RESPONSIBILITY',
  url:require('../../assets/headTitBgc.png')
},];
export default {
  props: ["nav"],
  data() {
    return {
      carousel_list: {
        carousel_list_1,
        carousel_list_2,
        carousel_list_3,
        carousel_list_4
      },
      carousel_bg: carousel_bg,
      carousel_index: 0,
      titleData:titleData
    };
  },
  methods: {
    carousel(newkey) {
      this.carousel_index = newkey;
    },
    setActiveItem(index) {
      this.$refs.carousel.setActiveItem(index);
    }
  }
};
</script>
<style scoped>
.head{
  margin-bottom: 100px;
}
.cn {
  font-size: 2em;
}
.title {
  position: relative;
}
.titleImg {
  width: 80%;
  max-height: 200px;
  position: absolute;
  bottom: -100px;
  z-index: 2;
}
.titCom {
  font-size: 40px;
  color: #fff;
  position: absolute;
  max-height: 200px;
  top: -60px;
  z-index: 3;
  margin-left: 10%;
}
.carousel {
  width: 100%;
  max-width: 1920px;
  height: 46.875vw;
  position: relative;
  /* overflow: hidden; */
}
.carousel .el-carousel {
  width: 90%;
  height: 45.875vw;
  position: absolute;
  top: 20px;
  left: 10vw;
}
.carousel .carousel_bg {
  position: absolute;
  height: 100%;
  top: 4vw;
  right: -1vw;
}
.carousel .carousel-indicator {
  position: absolute;
  left: 3%;
  top: 35%;
  width: 58px;
  text-align: center;
  display: flex;
  display: -webkit-flex;
  flex-direction: column;
  justify-content: center;
}
.carousel .carousel-indicator .carousel-indicator-view {
  display: block;
  width: 58px;
  height: 58px;
  border-radius: 50%;
  background-color: #ccc;
  font-size: 0;
  line-height: 58px;
  transform: scale(0.2);
}
.carousel .carousel-indicator .carousel-indicator-view-key {
  background: no-repeat;
  font-family: Roboto-MediumItalic;
  font-size: 40px;
  color: #333333;
  letter-spacing: 0;
  text-align: center;
  line-height: 58px;
  font-style: italic;
  font-weight: bold;
  transform: scale(1);
}
.el-carousel__item img {
  width: 100%
}
</style>


