<template>
  <div class="con">

  </div>
</template>
<script>
export default {
  name:'love'
}
</script>
<style scoped>
</style>


