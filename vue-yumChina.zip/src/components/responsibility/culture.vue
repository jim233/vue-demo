<template>
  <div>
    <div class="con wrapFont">
      <div>
        <div class="g-redDiv"></div>
        <div class="titFont">核心价值观和文化</div>
        <p class="head">为推动45余万名员工共同实现“全球最创新的餐饮先锋”这一愿景，百胜中国通过核心价值观和文化为全体员工绘制了一份蓝图。它不断启发我们、激励我们，推动我们取得突破性的成果。</p>
      </div>

      <div v-for="(item,index) in list" :key="index" class="content">
        <p v-for="(i,j) in item" :key="i" :class="j ==0?'secTit':''">
          {{i}}
        </p>
      </div>

      <img src="../../assets/culture.png" alt="" class="bgc">

      <p class="secTit content">餐厅经理第一：关注一线的拓业法则</p>
      <p>作为拓业法则之一，百胜中国长久以来一直遵循“餐厅经理第一”的企业文化。餐厅经理担任着公司最重要的领导岗位，在推动业务增长和提升顾客满意度方面发挥着不可或缺的作用。因此，我们从不吝于对餐厅经理的投资和培养，让他们不仅在营运方面发挥所长，同时也能通过为顾客提供优质服务而推动公司不断向前发展。百胜中国为餐厅经理提供了完整的职业发展路径，还为所有符合资格的餐厅经理提供股票奖励计划。</p>
    </div>
  </div>
</template>
<script>
const list = [
  ['我们的使命： 让生活更有滋味！',
    '我们认为，百胜中国的每位员工都应了解自己的工作目标和意义。我们应确保不断启发和激励员工，让他们在工作、生活乃至整个社会中发挥积极作用。我们以向顾客提供高质量的食物和用餐体验为荣，不断创新突破，让生活更有滋味。',
  ],[
    '我们的核心价值观： 共创、共享、共赢',
    '百胜中国一直努力为特障人士创造就业机会，我们对此引以为豪。通过一项创新的企业社会责任项目――肯德基“天使”餐厅，我们向特障群体提供就业机会。',
  ]
]
export default {
  name:'culture',
  data(){
    return{
      list:list
    }
  }
}
</script>
<style scoped>
.bgc{
  width: 100%;
}
p{
  margin-bottom: 30px;
}
.secTit{
  font-size: 32px;
  color: #333333;
}
.content{
  margin-top: 100px;
}
.head{
  font-family: SourceHanSansSC-Regular;
  font-size: 24px;
  color: #666666;
  letter-spacing: 0;
  text-align: justify;
  line-height: 48px;
  margin-top: 80px;
}
.wrapFont{
  font-family: SourceHanSansSC-Regular;
  font-size: 24px;
  color: #666666;
  letter-spacing: 0;
  text-align: justify;
  line-height: 48px;
}
.titFont {
  width: 95%;
  font-family: SourceHanSansSC-Medium;
  font-size: 60px;
  color: #333333;
  display: inline-block;
  vertical-align: top;
  line-height: 72px;
  margin-top: -10px;
}
.con {
  min-height: 100px;
}
</style>