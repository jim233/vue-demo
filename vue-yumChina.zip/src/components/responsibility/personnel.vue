<template>
  <div>
    <div class="con wrapFont">
      <div>
        <div class="g-redDiv"></div>
        <div class="titFont">人员能力第一：主导自我发展，提携他人成长</div>
        <p class="head">百胜中国业务多元，经营遍布全国，这要求我们建立的人才发展体系不仅能在全国范围内确保统一标准，更能尊重品牌差异化，保持高度互动。</p>
      </div>

      <div v-for="(item,index) in list" :key="index" class="content">
        <p v-for="(i,j) in item" :key="i" :class="j ==0?'secTit':''">
          {{i}}
        </p>
      </div>

      <img src="../../assets/peopleAbiliy.png" alt="" class="bgc">

      <div v-for="(item,index) in list2" :key="index+5" class="content">
        <p v-for="(i,j) in item" :key="j" :class="j ==0?'secTit':''">
          {{i}}
        </p>
      </div>
    </div>
  </div>
</template>
<script>
const list = [
  ['品牌运营培训：业内首屈一指的培训体系',
    '百胜中国拥有一流的品牌运营培训项目，适用于旗下所有餐厅不同职级的员工。该项目为员工提供培训机会和职业发展路径，帮助他们不断取得进步。2017 年，我们为肯德基和必胜客的餐厅员工提供的培训时长累计高达1400 万小时。此外，我们为不同级别的储备经理量身定制为期数月的培训项目，以确保他们充分发挥自身的潜能，最终成长为餐厅经理。',
  ],[
    '领军人物养成计划',
    '百胜中国“领军人物养成计划”由屡获殊荣的员工发展计划“黄埔军校”计划发展而来。 “黄埔军校”计划曾获人才发展协会（ATD）颁发的“组织学习和发展”领域的“卓越实践奖”。该奖项旨在表彰在职场学习和人才培养领域开展的具有示范性的实践活动。2012 年，百胜中国推出了“黄埔军校”计划，帮助员工开展店内学习、课堂培训和课后实践学习。该计划为高素质、教育背景良好但缺乏工作经验或者餐饮行业经验的应届毕业生提供快速成长的机会，在较短的时间内（平均3 至3.5 年）将这些员工培养成餐厅经理。',
  ],[
    '职业发展：清晰定义的职业发展路径',
    '百胜中国的营运管理团队实现100%由内部晋升。公司拥有清晰的职业发展路径，引导员工在职业生涯的不同阶段进行职业规划。'
  ],
  ['接力棒计划',
    '营运经理占公司管理团队总人数的90%，是公司的中坚力量。为了让有才华的管理人员得到成长并充分发挥他们的潜能，我们为其设计了完善的职业发展路径。这一清晰的职业路径展现了员工如何从储备经理成长为餐厅经理乃至市场总经理等更高职位的过程。我们有许多高层领导正是在百胜中国开启他们的职业生涯，并沿着被称为“接力棒计划”的职业发展路径最终取得了职业上的成功。我们希望这一职业路径既能满足百胜中国迅速增长的人才需求，又能充分体现我们的人才发展理念，每个人都能不断超越前行。'
  ]
]
const list2 = [
  [
    '学生直通车',
    '我们十分重视对年轻人才的招募和留任。百胜中国在全国范围内开展实习生项目，寻找表现杰出、吃苦耐劳、与公司拥有共同价值观的候选人。学生直通车项目的所有参与者都会接受入职所需的操作技能培训。大学毕业之后，学生将在百胜中国开启职业发展道路。'
  ],[
    '百胜中国领导力模型',
    '“领导力”模型主要被运用于百胜中国的各类人才发展项目、高潜评选和招聘等领域。借用红杉树这一世界上最古老的高大树种和其屹立长青的形象，百胜中国的领导力模型旨在指导培养拥有红杉树一样扎实根基的领导人。百胜中国着力于打造领导力品格，助力“建设攻坚团队”并最终“驱动跃进结果”。'
  ]
]
export default {
  name:'culture',
  data(){
    return{
      list:list,
      list2:list2
    }
  }
}
</script>
<style scoped>
.bgc{
  width: 100%;
}
p{
  margin-bottom: 30px;
}
.secTit{
  font-size: 32px;
  color: #333333;
}
.content{
  margin-top: 100px;
}
.head{
  font-family: SourceHanSansSC-Regular;
  font-size: 24px;
  color: #666666;
  letter-spacing: 0;
  text-align: justify;
  line-height: 48px;
  margin-top: 80px;
}
.wrapFont{
  font-family: SourceHanSansSC-Regular;
  font-size: 24px;
  color: #666666;
  letter-spacing: 0;
  text-align: justify;
  line-height: 48px;
}
.titFont {
  width: 95%;
  font-family: SourceHanSansSC-Medium;
  font-size: 60px;
  color: #333333;
  display: inline-block;
  vertical-align: top;
  line-height: 72px;
  margin-top: -10px;
}
.con {
  min-height: 100px;
}
</style>