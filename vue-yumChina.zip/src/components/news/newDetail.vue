<template>
  <div class="wrap">
    <div class="head">
      <img src="../../assets/newsDetail1.png" style='width:90%' alt="公司简介">
      <div class="title">
        <div class="g-redDiv"></div>
        <span>百胜中国在上海再推出两家塔可贝尔餐厅</span>
      </div>
    </div>
    <div class="main">
      <div class="content">
        <div @click="$router.go(-1)" class="return">返回列表</div>
      </div>
    </div>
    <div class="foot">
      <div class="footLeft footCon">
        <img src="../../assets/return.png" class="leftImg" alt="">
        上一篇
      </div>
      <div class="footRight footCon">
        下一篇
        <img src="../../assets/return.png" alt="">
      </div>
    </div>
  </div>

</template>
<script>
export default {
  name:'newDetail'
}
</script>
<style scoped>
.leftImg{
  transform:rotate(180deg);
  -ms-transform:rotate(180deg); 	/* IE 9 */
  -moz-transform:rotate(180deg); 	/* Firefox */
  -webkit-transform:rotate(180deg); /* Safari 和 Chrome */
  -o-transform:rotate(180deg); 	/* Opera */
}
.foot img{
  width: 22px;
}
.footRight{
  text-align: right;
}
.footCon{
  width: 50%;
  display: inline-table;
  vertical-align: top;
  min-height: 50px;
  font-family: SourceHanSansSC-Regular;
  font-size: 24px;
  color: #666666;
  letter-spacing: 0;
  line-height: 24px;
  margin-top: 50px;
}
.foot{
  background-color: #fff;
  min-height: 300px;
  padding: 0 20%;
}
.return{
  padding: 1% 5%;
  background: #FFFFFF;
  border: 1px solid #333333;
  font-size: 24px;
  text-align: center;
  line-height: 24px;
  position: absolute;
  right: 0px;
  bottom:50px;
}
.main{
  background-color: #f5f5f5;
  width: 100%;
  box-sizing: border-box;
  padding:0 20%;
}
.content{
  width: 100%;
  min-height: 500px;
  position: relative;
  box-sizing: border-box
}
.head {
  text-align: right;
  position: relative;
}
.title {
  width: 80%;
  padding: 2% 0 2% 12%;
  position: absolute;
  bottom: -65px;
  z-index: 2;
  background-color: #fff;
  text-align: left;
  font-family: SourceHanSansSC-Medium;
  font-size: 45px;
  color: #333333;
  letter-spacing: 0;
}
</style>


