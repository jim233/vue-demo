<template>
  <div class="wrap">
    <Header name='新闻中心' nameEn='NEWS'></Header>
    <div class="content">
      <div class="left">
        <div  @click="year($event)">
          <div class="fontRed">ALL</div>
          <div>2018</div>
          <div>2017</div>
          <div>2016</div>
          <div>2015</div>
          <div>2014</div>
        </div>
      </div>
      <div class="right">
        <div class="head">
          <div :class="[activeName == 0?'active':'','title']" @click="activeName = '0'">新闻稿</div>
          <div :class="[activeName == 1?'active':'','title']" @click="activeName = '1'">媒体报道</div>
        </div>
        <div v-show="activeName==0">
          <div>
            <div class="leftCon mainCon">
              <p class="newsTit">百胜中国在全国启动必胜客“悦读食光”公益阅读项目</p>
              <p class="newsCon">中国上海（2018年5月2日）——百胜中国控股有限公司（“百胜中国”，纽约证券交易所代码：YUMC）在今年的“世界读书日”上，宣布在其所有必胜客餐厅，启动…</p>
              <div class="more">
                <span>2018-05-02  17:12</span>
                <router-link class="moreCon" to='/newDetail/1'>
                  了解更多
                  <img src="../../assets/return.png" alt="" class="next">
                </router-link>
              </div>
            </div>
            <div class="rightCon mainCon">
              <img src="../../assets/news1.png" class="rigImg">
            </div>
          </div>
        </div>
        <div v-show="activeName==1">
          暂无
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Header from "../about/head.vue";
export default {
  name:'newsCenter',
  components: {
    Header
  },
  data(){
    return{
      activeName:this.$route.params.id
    }
  },
  methods:{
    year(e){

    }
  },
  watch:{
    $route(){
      this.activeName = this.$route.params.id
    }
  }
}
</script>
<style scoped>
a{
  color: #999999;
}
.moreCon{
  position: absolute;
  right: 0;
  display: inline-block;
  vertical-align: top;
}
.more{
  font-family: Roboto-Regular;
  font-size: 22px;
  color: #999999;
  letter-spacing: 0;
  line-height: 28px;
  box-sizing: border-box;
  margin-top: 40px;
  position: relative;
}
.next{
  width: 22px;
  margin-left: 10px
}
.newsCon{
  font-family: SourceHanSansSC-Regular;
  font-size: 22px;
  color: #666666;
  letter-spacing: 0;
  text-align: justify;
  line-height: 48px;
}
.newsTit{
  font-family: SourceHanSansSC-Medium;
  font-size: 34px;
  color: #333333;
  letter-spacing: 0;
  text-align: justify;
  line-height: 54px;
  margin-bottom: 24px;
}
.leftCon{
  margin-right: 3%;
  width: 50%;
}
.rightCon{
  width: 47%
}
.rigImg{
  width: 100%;
}
.mainCon{
  display: inline-block;
  vertical-align: top;
}
.active{
  color: #333333;
  border-bottom:5px solid #d4343a
}
.title{
  display: inline-block;
  vertical-align: top;
  margin-right: 8%;
  padding: 20px 0;
}
.head{
  font-family: SourceHanSansSC-Regular;
  font-size: 55px;
  color: #666666;
  letter-spacing: 0;
  line-height: 60px;
  margin: 60px 0 80px 0;
}
.content .fontRed {
  color: #d4343a;
}
.right {
  width: 82.3%;
  display: inline-block;
  vertical-align: top;
  box-sizing: border-box;
  padding: 0 8%;
  min-height: 200px;
  margin-left: 17.7%;
  min-height: 1500px;
}
.left div {
  font-family: Roboto-Medium;
  font-size: 30px;
  color: #666666;
  line-height: 40px;
  margin: 30px 0;
}
.left {
  width: 17.7%;
  background-color: #f5f5f5;
  position: absolute;
  height: 100%;
  padding-left: 10%;
  box-sizing: border-box;
  display: inline-block;
  vertical-align: top;
  padding-top: 10%;
}
.content {
  width: 100%;
  min-height: 200px;
  position: relative;
}
</style>
