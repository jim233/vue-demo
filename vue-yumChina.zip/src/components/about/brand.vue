<template>
  <div class="wrap">
    <Header name='品牌家族' nameEn='OUR BRANDS'></Header>
    <div class="con">
      <div class="title">
        <div class="red"></div>
        <span class="titFont">公司介绍</span>
      </div>
      <div class="content">
        <p>百胜中国控股有限公司是中国领先的餐饮公司，致力于让生活更有滋味。自从1987年第一家餐厅开业以来，百胜中国今天在大陆的足迹遍布所有省市自治区，在1,200多座城镇经营着8,100余家餐厅。</p>
      </div>
    </div>

    <div class="main">
      <div class="mainCon" style="background-color: #fff;" >
        <div class="left">
          <div class="head">
            <span>肯德基</span>
            <img src='../../assets/pic_brands_logo_kfc.png' class="logo" alt=";ogo">
          </div>
          <div class="mainContent">
            <p>按照系统销售额与餐厅数量计算，肯德基是中国领先的餐饮品牌，也是全球知名鸡肉餐饮连锁店。1952年由山德士上校（Colonel Harland Sanders）在美国创建 。自1987年在北京开设第一家门店以来，肯德基已开设了5000余家连锁餐厅。 </p> 
            <p> 我们一直致力于将肯德基的美味带给更多的消费者。我们苦练内功，制作出让顾客每次都可以满意而归的美味食物与就餐体验。在原味炸鸡的基础上，我们还推出一系列更加符合本土口味的产品，包括猪肉、牛肉、海产品、米饭、蔬菜、汤、早餐、甜点等类的特色美食。</p> 
          </div>
          <div class="wei">
            <div>
              <img src="../../assets/weixin.png" class="weiImg marRight" alt="微信">
              <img src="../../assets/ic_share_weibo.png" class="weiImg" alt="微博">
            </div>
            <div>
              <span>肯德鸡官网</span>
              <img src="../../assets/return.png" class="return" alt="连接">
            </div>
          </div>
        </div>
        <div class="right">
          <img src="../../assets/brand_kfc.png" class="imgBgc">
        </div>
      </div>
      <div class="mainCon">
        <div class="right">
          <img src="../../assets/brand_kfc.png" class="imgBgc">
        </div>
        <div class="left">
          <div class="head">
            <span>肯德基</span>
            <img src='../../assets/pic_brands_logo_kfc.png' class="logo" alt=";ogo">
          </div>
          <div class="mainContent">
            <p>按照系统销售额与餐厅数量计算，肯德基是中国领先的餐饮品牌，也是全球知名鸡肉餐饮连锁店。1952年由山德士上校（Colonel Harland Sanders）在美国创建 。自1987年在北京开设第一家门店以来，肯德基已开设了5000余家连锁餐厅。 </p> 
            <p> 我们一直致力于将肯德基的美味带给更多的消费者。我们苦练内功，制作出让顾客每次都可以满意而归的美味食物与就餐体验。在原味炸鸡的基础上，我们还推出一系列更加符合本土口味的产品，包括猪肉、牛肉、海产品、米饭、蔬菜、汤、早餐、甜点等类的特色美食。</p> 
          </div>
          <div class="wei">
            <div>
              <img src="../../assets/weixin.png" class="weiImg marRight" alt="微信">
              <img src="../../assets/ic_share_weibo.png" class="weiImg" alt="微博">
            </div>
            <div>
              <span>肯德鸡官网</span>
              <img src="../../assets/return.png" class="return" alt="连接">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Header from "./head.vue";
export default {
  name: "brand",
  components: {
    Header
  }
};
</script>
<style scoped>
.return{
  margin-left: 8px;
}
.marRight{
  margin-right: 60px;
}
.weiImg{
  width: 40px;
  height: 40px;
}
.wei{
  display: flex;
  display: -webkit-flex;
  justify-content:space-between;
  align-items: center;
  margin:7% 0;
  font-family: SourceHanSansSC-Regular;
  font-size: 24px;
  color: #666666;
  letter-spacing: 0;
  text-align: right;
  line-height: 24px;
}
.mainContent{
  font-size: 20px;
  color: #666666;
  letter-spacing: 0;
  text-align: justify;
  line-height: 40px;
}
.mainCon {
  margin-bottom: 5%;
}
.head {
  position: relative;
  padding: 4% 0;
  font-family: SourceHanSansSC-Medium;
  font-size: 60px;
  color: #333333;
  letter-spacing: 0;
  text-align: left;
  display: flex;
  display: -webkit-flex;
  justify-content: space-between;
  align-items: center
}
.logo {
  width: 12.9%;
  height: auto;
}
.imgBgc {
  vertical-align: bottom;
  width: 100%;
  height: auto;
}
.left {
  width: 67.7%;
  min-height: 200px;
  display: inline-block;
  vertical-align: bottom;
  padding: 0 10%;
  box-sizing: border-box;
  box-shadow: 0 0 4px 0 rgba(0,0,0,0.15);
  background-color: #fff;
}
.right {
  width: 32.3%;
  display: inline-block;
  min-height: 200px;
  vertical-align: bottom;
}
.main {
  background-color: #f5f5f5;
  border: transparent;
}
.content {
  width: 60%;
  font-family: SourceHanSansSC-Regular;
  font-size: 24px;
  color: #666666;
  letter-spacing: 0;
  text-align: justify;
  line-height: 48px;
  display: inline-block;
}
.title {
  display: flex;
  display: -webkit-flex;
  width: 40%;
  display: inline-block;
  vertical-align: top;
}
.titFont {
  font-family: SourceHanSansSC-Medium;
  font-size: 45px;
  color: #333333;
}
.red {
  width: 10px;
  height: 60px;
  background: rgba(212, 52, 58, 1);
  margin-right: 3%;
  vertical-align: top;
  display: inline-block;
}
.con {
  padding: 2% 10%;
}
</style>