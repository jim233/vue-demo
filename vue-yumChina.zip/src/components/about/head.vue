<template>
  <div class="wrap">
    <div class="head">
      <img src="../../assets/companyBgc.png" style='width:90%' alt="公司简介">
      <div class="title">
        <img src="../../assets/footer_pic_bg.png" class="titleImg" alt="标题">
        <div class="titCom">
          <p class="cn">{{name}}</p>
          {{nameEn}}
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  props:['name','nameEn']
}
</script>
<style scoped>
.cn {
  font-size: 2em;
}
.head {
  text-align: right;
  position: relative;
  margin-bottom: 100px;
}
.title {
  text-align: left;
  position: relative;
}
.titleImg {
  width: 80%;
  max-height: 200px;
  position: absolute;
  bottom: -100px;
  z-index: 2;
}
.titCom {
  font-size: 40px;
  color: #fff;
  position: absolute;
  max-height: 200px;
  top: -80px;
  z-index: 2;
  margin-left: 10%;
}
</style>


