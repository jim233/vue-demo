<template>
  <div class="wrap">
    <Header name='公司简介' nameEn='OVERVIEW'></Header>
    <div class="con">
      <div class="company">
        <div style="display: flex;display: -webkit-flex; width:40%">
          <div class="red"></div>
          <div class="titFont">公司介绍</div>
        </div>
        <div class="content">
          <p>百胜中国控股有限公司是中国领先的餐饮公司，致力于让生活更有滋味。自从1987年第一家餐厅开业以来，百胜中国今天在大陆的足迹遍布所有省市自治区，在1,200多座城镇经营着8,100余家餐厅。</p>
          <p>百胜中国从Yum! Brands（纽约证券交易所代码：YUM）分拆出来之后，于2016年11月1日独立在纽约证券交易所上市，股票代码为YUMC。百胜中国在中国市场拥有肯德基、必胜客和塔可贝尔三个品牌的独家运营和授权经营权，并完全拥有东方既白和小肥羊连锁餐厅。</p>
          <div class="view">
            查看更多
          </div>
        </div>
      </div>
      <div class="pad">
        <div style="display: flex;display: -webkit-flex; width:40%">
          <div class="red"></div>
          <div class="titFont">企业文化</div>
        </div>
        <div style="display: flex; display: -webkit-flex;width:100%;align-items: center">
          <div style="width:40%" class="customer">
            <p style="font-size: 36px;padding:2% 0;">为客疯狂</p>
            <p>外部顾客：</p>
            <p>- 洞察并引领消费者的想法。</p>
            <p>- 以YES的态度服务每一位顾客，为他们创造惊喜。</p>
            <p>内部顾客：</p>
            <p>- 认同RGM NO.1理念，同时以餐厅伙伴为中心。</p>
            <p>- 以YES的态度和其他同事协作，积极提供有价值的方案。</p>
          </div>
          <div style="width:60%" class="clearfix">
            <div class="div">
              <div class="divCon" style="background-color: #F43B42;box-shadow: 0 15px 18px 0 rgba(51,51,51,0.30)">为客户疯狂</div>
              <div class="divCon" style="background-color: #FFBB3F">求知若渴</div> 
              <div class="divCon" style="background-color: #F76633">互信支持</div>
            </div>
            <div class="div" style="margin-top:5%">
              <div class="divCon" style="background-color: #FF7341">创业创新</div>
              <div class="divCon" style="background-color: #F43B42;">正直诚信</div>
              <div class="divCon" style="background-color: #FFBB3F">贯彻卓越</div>
            </div>
            <div class="div" style="margin-top:15%">
              <div class="divCon" style="background-color: #FFBB3F">认同鼓励</div>
              <div class="divCon" style="background-color: #F76633">回馈社会</div>
            </div>
          </div>
        </div>
      </div>
      <div>
        <div style="display: flex;display: -webkit-flex; width:30%">
          <div class="red"></div>
          <div class="titFont">在华大事记</div>
        </div>
        <div class="china">
          <div class="cCon">
            <p style="font-size:36px;">2017</p>
            <div class="dot"></div>
            <p>上海：塔可贝尔在中国的第一家餐厅开业</p>
            <img src="../../assets/tacoBell.png" alt="TACOBELL" class="cImg">
          </div>
          <div class="cCon">
            <p style="font-size:36px;">2016</p>
            <div class="dot"></div>
            <p>2016年11月1日，百胜中国在纽交所上市</p>
            <img src="../../assets/logo.png" alt="TACOBELL" class="cImg">
          </div>
          <div class="cCon">
            <p style="font-size:36px;">2015</p>
            <div class="dot"></div>
            <p>肯德基在中国的第5000家餐厅</p>
            <img src="../../assets/pic_brands_logo_kfc.png" alt="TACOBELL" class="cImg">
          </div>
          <div class="cCon">
            <p style="font-size:36px;">2013</p>
            <div class="dot"></div>
            <p>必胜客在中国的第1000家餐厅</p>
            <img src="../../assets/bsk.png" alt="TACOBELL" class="cImg">
          </div>
          <div class="cCon">
            <p style="font-size:36px;">2012</p>
            <div class="dot"></div>
            <p>Yum ! Brands 收购小肥羊</p>
            <img src="../../assets/pic_brands_logo_littlesheep.png" alt="TACOBELL" class="cImg">
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Header from './head.vue'
export default {
  name: "companyIntro",
  components:{
    Header
  },
  created(){
    this.$axios('/Brand/Details').then(res=>{
      console.log(res)
    })
  }
};
</script>
<style scoped>
@media screen and (max-width: 600px) {
  .wrap .con{
    padding: 2%;
  }
  .wrap .head{
    margin-bottom: 25px;
  }
  .wrap .titCom{
    font-size: 16px;
    top:-30px
  }
  .wrap .cn{
    font-size: 24px;
  }
  .wrap .titleImg{
    bottom:-25px
  }
}
.cImg{
  margin-top:20px;
  width: 100px;
}
.dot{
  display: inline-block;
  width: 10px;
  height: 10px;
  background-color: rgba(212,52,58,1);
  border-radius: 50px
}
.cCon{
  width: 20%;
  padding: 20px 2%;
  text-align: center;
  box-sizing: border-box;
  display: inline-block;
  vertical-align: top;
}
.china{
  width: 100%;
  font-size:24px;
  font-family:SFNSDisplay;
  color:rgba(51,51,51,1);
  line-height:48px;
}
.divCon{
  width: 100%;
  padding: 20px;
  box-sizing: border-box;
  height: 200px;
}
.clearfix:after {
  content: ".";
  height: 0;
  display: block;
  clear: both;
}
.div {
  float: left;
  width: 33.33%;
}
.customer {
  padding: 20px;
  background-color: #fefefe;
  font-family: SourceHanSansSC-Medium;
  font-size: 24px;
  color: #666666;
  border: 1px solid #fcfcfc;
  border-right: none;
  border-top-left-radius: 5px;
  border-bottom-left-radius: 5px;
  box-shadow: 0 0 4px 0 rgba(0,0,0,0.15);
  line-height: 48px;
}
.view {
  width: 25%;
  height: 50px;
  line-height: 50px;
  border: 1px solid #333;
  text-align: center;
  font-size: 24px;
  color: #333;
  margin-top: 5%;
}
.pad {
  padding: 5% 0;
}
.content {
  width: 60%;
  font-family: SourceHanSansSC-Regular;
  font-size: 24px;
  color: #666666;
  letter-spacing: 0;
  text-align: justify;
  line-height: 48px;
}
.titFont {
  font-family: SourceHanSansSC-Medium;
  font-size: 45px;
  color: #333333;
}
.company {
  display: flex;
  justify-content: space-between;
}
.red {
  width: 10px;
  height: 60px;
  background: rgba(212, 52, 58, 1);
  margin-right: 3%;
  vertical-align: top;
}
.con {
  padding: 2% 10%;
}
.cn {
  font-size: 2em;
}
.head {
  text-align: right;
  position: relative;
  margin-bottom: 100px;
}
.title {
  text-align: left;
  position: relative;
}
.titleImg {
  width: 80%;
  max-height: 200px;
  position: absolute;
  bottom: -100px;
  z-index: 2;
}
.titCom {
  font-size: 40px;
  color: #fff;
  position: absolute;
  max-height: 200px;
  top: -80px;
  z-index: 2;
  margin-left: 10%;
}
</style>