<template>
  <div class="wrap">
    <Header name='公司荣誉' nameEn='Our Honor'></Header>
    <div class="content">
      <div class="left">
        <div @click="click($event)">
          <div>2018</div>
          <div class="fontRed">2017</div>
          <div>2016</div>
          <div>2015</div>
          <div>2014</div>
          <div>2013</div>
          <div>2012</div>
        </div>
      </div>
      <div class="right">
        <div class="title">
          <div class="red"></div>
          <span class="titFont">百胜中国近年所获奖项和荣誉</span>
        </div>
        <div class="conWrap">
          <div class="con">
            <div class="head">
              <img src="../../assets/honor.png" alt="荣誉"><br/>
              <div class="titleSec">
                <div class="border"></div>
                2017
                <div class="border"></div>
              </div>
              <ul>
                <p> • 荣获第二届“社会价值共创”中国企业社会责任卓越卓越奖（捐一元）</p>
                <p> • 在公益时报“2017 中国公益年会”中荣获“2017年度中国公益企业”荣誉称号（捐一元、肯德基小候鸟基金）</p>
                <p> • 荣获中国扶贫基金会颁发的年度“卓越贡献奖”（捐一元）</p>
                <p> • 荣获中国扶贫基金会颁发的“2016 年度卓越贡献奖”（捐一元）</p>
                <p> • 荣获“2016 南方公益传播奖之年度奖”（捐一元）</p>
                <p> • 荣获南方周末“年度责任案例奖”（肯德基小候鸟基金）</p>
                <p> • 在南方出版传媒股份有限公司与《新周刊》杂志联合主办的“2017 企业社会责任荣誉盛典”上斩获“最佳慈善表现”奖（“天使餐厅”项目）</p>
                <p> • 在“智联招募2017 中国百强雇主”评选中荣获“最佳雇主100强”</p>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import Header from "./head.vue";
export default {
  name: "honor",
  components: {
    Header
  },
  methods:{
    click(e){
      console.log(e.target)
    }
  }
};
</script>
<style scoped>
ul {
  font-family: SourceHanSansSC-Regular;
  font-size: 20px;
  color: #666666;
  letter-spacing: 0;
  line-height: 48px;
  text-align: left
}
.border {
  width: 60px;
  height: 8px;
  display: inline-block;
  border-top: 2px solid #ccc;
  border-bottom: 2px solid #ccc;
  margin: 0 20px;
  position: relative;
  top: -10px;
}
.titleSec {
  display: inline-block;
  font-family: SourceHanSansSC-Regular;
  font-size: 36px;
  color: #333333;
  letter-spacing: 0;
  text-align: justify;
  line-height: 48px;
  margin: 35px 0 60px;
}
.head {
  text-align: center;
}
.con {
  border: 1px solid #f5f5f5;
  border-radius: 8px;
  min-height: 200px;
  padding: 4% 5%;
  box-sizing: border-box;
}
.conWrap {
  background: #ffffff;
  box-shadow: 0 0 4px 0 rgba(0, 0, 0, 0.15);
  border-radius: 12px;
  min-height: 200px;
  padding: 10px;
  margin-bottom: 8%;
}
.title {
  vertical-align: top;
  margin: 80px 0;
}
.titFont {
  font-family: SourceHanSansSC-Medium;
  font-size: 45px;
  color: #333333;
}
.red {
  width: 10px;
  height: 60px;
  background: rgba(212, 52, 58, 1);
  margin-right: 3%;
  vertical-align: top;
  display: inline-block;
}
.wrap .fontRed {
  color: #d4343a;
}
.right {
  width: 82.3%;
  display: inline-block;
  vertical-align: top;
  padding: 0 8%;
  min-height: 200px;
  box-sizing: border-box;
  margin-left: 17.7%
}
.left div {
  font-family: Roboto-Medium;
  font-size: 30px;
  color: #666666;
  line-height: 40px;
  margin: 30px 0;
}
.left {
  width: 17.7%;
  background-color: #f5f5f5;
  position: absolute;
  height: 100%;
  padding-left: 10%;
  box-sizing: border-box;
  display: inline-block;
  vertical-align: top;
  display: flex;
  display: -webkit-flex;
  align-items: center;
}
.content {
  width: 100%;
  min-height: 200px;
  position: relative;
}
</style>


