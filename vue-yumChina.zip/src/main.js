import Vue from 'vue'
// import './plugins/axios'
import App from './App.vue'
import './plugins/element.js'
import i18n from './i18n'
import router from '@/router.js'
import axios from "axios";
Vue.config.productionTip = false
Vue.prototype.$axios = axios
new Vue({
  i18n,
  router,
  render: h => h(App)
}).$mount('#app')
