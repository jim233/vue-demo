import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  routes: [{
    path: '/',
    name: 'main',
    component: () =>
      import('./components/main.vue')
  }, {
    path: '/companyIntro',
    name: 'companyIntro',
    component: () =>
      import('./components/about/companyIntro.vue')
  }, {
    path: '/brand',
    name: 'brand',
    component: () =>
      import('./components/about/brand.vue')
  }, {
    path: '/honor',
    name: 'honor',
    component: () =>
      import('./components/about/honor.vue')
  }, {
    path: '/respIndex',
    name: 'respIndex',
    component: () =>
      import('./components/responsibility/index.vue')
  }, {
    path: '/respMain',
    name: 'respMain',
    component: () =>
      import('./components/responsibility/main.vue')
  }, {
    path: '/joinIn',
    name: 'joinIn',
    component: () =>
      import('./components/joinIn.vue')
  }, {
    path: '/newsCenter/:id', //:id  展示哪一个标签也
    name: 'newsCenter',
    component: () =>
      import('./components/news/newsCenter.vue')
  }, {
    path: '/newDetail/:id', //id  代表那一条新闻
    name: 'newDetail',
    component: () =>
      import('./components/news/newDetail.vue')
  }, {
    path: '/legal',
    name: 'legal',
    component: () =>
      import('./components/legal.vue')
  }, {
    path: '/website',
    name: 'website',
    component: () =>
      import('./components/website.vue')
  }, {
    path: '/statement',
    name: 'statement',
    component: () =>
      import('./components/statement.vue')
  },{
    path: '/notes',
    name: 'notes',
    component: () =>
      import('./components/supplier/notes.vue')
  },{
    path: '/info',
    name: 'info',
    component: () =>
      import('./components/supplier/info.vue')
  },]
})