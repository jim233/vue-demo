import Vue from 'vue'
import App from '@/App.vue'
import '@/plugins/element'
import i18n from '@/i18n'
import router from '@/router.js'
import axios from "axios";

// import '@/plugins/axios'
Vue.prototype.$axios = axios

Vue.config.productionTip = false
new Vue({
  i18n,
  router,
  render: h => h(App)
}).$mount('#app')
